<?php
/**
 * Plugin Name:  Zurca Glop Sync
 * Plugin URI:   https://github.com/salirenbuscadore/zurca-glop-sync
 * Description:  Sincronización Glop TPV ↔ WooCommerce · Club Zurca · Base de clientes unificada.
 * Version:      1.2.0
 * Author:       Zurca Mercado Natural
 * Author URI:   https://zurcanatural.com
 * License:      MIT
 * Text Domain:  zurca-glop-sync
 *
 * ─────────────────────────────────────────────────────────────
 * HISTORIAL DE VERSIONES
 * ─────────────────────────────────────────────────────────────
 * 1.0.0  (2026-05-xx)  Versión inicial. Estructura base.
 *
 * 1.1.0  (2026-06-17)  Formulario Club Zurca + actualizaciones GitHub.
 *                      · Shortcode [club_zurca_registro]
 *                      · Endpoint REST POST /wp-json/zurca/v1/registro
 *                      · Tabla wp_zurca_club_members
 *                      · Plugin Update Checker → GitHub
 *
 * 1.2.0  (2026-06-17)  Reescritura limpia.
 *                      · Eliminadas funciones duplicadas con AI Engine MCP
 *                        (crear páginas, posts, productos — ya los gestiona
 *                        el MCP de AI Engine con 19 herramientas nativas)
 *                      · El plugin se centra SOLO en lo exclusivo de Zurca:
 *                        · Sincronización Glop API ↔ WooCommerce
 *                        · Club Zurca: tabla, endpoint REST, formulario
 *                        · Página de ajustes (Glop, Make, Brevo)
 *                      · Repo público: github.com/salirenbuscadore/zurca-glop-sync
 *                      · Sin token necesario para actualizaciones automáticas
 *
 * 1.3.0  (PENDIENTE — jueves implantación Glop API)
 *                      · Credenciales Glop API reales (soporte@glop.es)
 *                      · Importación masiva 982 clientes CSV → Glop
 *                      · Sincronización automática registro web → Glop
 *                      · zurca_glop_crear_cliente() activado
 * ─────────────────────────────────────────────────────────────
 *
 * ARQUITECTURA
 * ─────────────────────────────────────────────────────────────
 * Lo que hace ESTE plugin (exclusivo de Zurca):
 *   includes/class-glop-api.php   → cliente Glop API
 *   includes/club-zurca-form.php  → formulario Club Zurca + endpoint REST
 *   includes/admin-settings.php   → ajustes WP Admin
 *   assets/club-form.css / .js    → estilos y scripts del formulario
 *
 * Lo que NO hace este plugin (delegado a AI Engine MCP):
 *   · Crear/editar páginas y posts
 *   · Gestionar productos WooCommerce
 *   · Subir media
 *   · Cualquier operación CRUD de WordPress
 * ─────────────────────────────────────────────────────────────
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ZURCA_VERSION',    '1.2.0' );
define( 'ZURCA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'ZURCA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ── 1. Actualizaciones automáticas desde GitHub (repo público) ─
require_once ZURCA_PLUGIN_DIR . 'vendor/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$zurca_updater = PucFactory::buildUpdateChecker(
    'https://github.com/salirenbuscadore/zurca-glop-sync',
    __FILE__,
    'zurca-glop-sync'
);
$zurca_updater->setBranch( 'main' );
// Repo público → sin token necesario

// ── 2. Cargar módulos ─────────────────────────────────────────
require_once ZURCA_PLUGIN_DIR . 'includes/class-glop-api.php';
require_once ZURCA_PLUGIN_DIR . 'includes/club-zurca-form.php';
require_once ZURCA_PLUGIN_DIR . 'includes/admin-settings.php';

// ── 3. Activación ────────────────────────────────────────────
register_activation_hook( __FILE__, 'zurca_activar' );

function zurca_activar() {
    zurca_club_crear_tabla();
    add_option( 'zurca_glop_api_key',     '' );
    add_option( 'zurca_glop_api_url',     'https://apidoc.glop.es' );
    add_option( 'zurca_make_webhook_url', '' );
    add_option( 'zurca_brevo_api_key',    '' );
    add_option( 'zurca_brevo_sms_sender', 'Zurca' );
}
