/* Zurca Club Form v1.1.0 */
(function() {
  'use strict';

  function $(id) { return document.getElementById(id); }
  function telValido(t) { return /^(\+?34)?[6789]\d{8}$/.test(t.replace(/[\s\-\.]/g, '')); }
  function emailValido(e) { return !e || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }
  function cpValido(c) { return /^\d{5}$/.test(c); }

  function setError(campo, msg, show) {
    var err = $('zerr-' + campo);
    var inp = $('zc-' + campo);
    if (!err) return;
    if (show) { err.classList.add('visible'); if (inp) inp.classList.add('zc-error'); }
    else       { err.classList.remove('visible'); if (inp) inp.classList.remove('zc-error'); }
  }

  // Solo dígitos en CP
  var cpEl = $('zc-cp');
  if (cpEl) cpEl.addEventListener('input', function() { this.value = this.value.replace(/\D/g,''); });

  var btn = $('zurca-btn-registro');
  if (!btn) return;

  btn.addEventListener('click', function() {
    var nombre    = ($('zc-nombre')    || {value:''}).value.trim();
    var apellidos = ($('zc-apellidos') || {value:''}).value.trim();
    var telefono  = ($('zc-telefono')  || {value:''}).value.trim();
    var cp        = ($('zc-cp')        || {value:''}).value.trim();
    var email     = ($('zc-email')     || {value:''}).value.trim();
    var cumple    = ($('zc-cumple')    || {value:''}).value;
    var gdpr      = ($('zc-gdpr')      || {checked:false}).checked;

    ['nombre','apellidos','telefono','cp','email','gdpr'].forEach(function(c){ setError(c,'',false); });
    $('zurca-error-global').textContent = '';

    var ok = true;
    if (!nombre)             { setError('nombre','',true);    ok = false; }
    if (!apellidos)          { setError('apellidos','',true); ok = false; }
    if (!telValido(telefono)){ setError('telefono','',true);  ok = false; }
    if (!cpValido(cp))       { setError('cp','',true);        ok = false; }
    if (!emailValido(email)) { setError('email','',true);     ok = false; }
    if (!gdpr)               { setError('gdpr','',true);      ok = false; }
    if (!ok) return;

    btn.disabled = true;
    $('zurca-btn-texto').textContent = 'Guardando...';

    fetch(zurcaClub.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json',
        'X-WP-Nonce':    zurcaClub.nonce,
      },
      body: JSON.stringify({
        nombre: nombre, apellidos: apellidos,
        telefono: telefono, cp: cp,
        email: email, cumpleanos: cumple, gdpr: true,
      }),
    })
    .then(function(r) { return r.json().then(function(d){ return {ok: r.ok, data: d}; }); })
    .then(function(res) {
      if (res.ok) {
        $('zurca-form-inner').style.display = 'none';
        $('zurca-exito-nombre').textContent = nombre;
        $('zurca-exito').style.display = 'block';
      } else {
        $('zurca-error-global').textContent = res.data.message || 'Ha ocurrido un error. Inténtalo de nuevo.';
        btn.disabled = false;
        $('zurca-btn-texto').textContent = 'Registrarme en el Club';
      }
    })
    .catch(function() {
      $('zurca-error-global').textContent = 'Error de conexión. Inténtalo de nuevo.';
      btn.disabled = false;
      $('zurca-btn-texto').textContent = 'Registrarme en el Club';
    });
  });

  // Enter en campos
  document.querySelectorAll('.zurca-club-wrap input').forEach(function(inp) {
    inp.addEventListener('keydown', function(e) { if (e.key === 'Enter') btn.click(); });
  });
})();
