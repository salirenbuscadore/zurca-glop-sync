# Zurca Glop Sync — Historial de cambios

## [1.2.0] — 2026-06-17

### Cambiado
- Reescritura limpia: eliminadas todas las funciones duplicadas con AI Engine MCP
- El plugin ahora se centra exclusivamente en: Glop API, Club Zurca, ajustes
- Gestión de páginas, posts y productos delegada al MCP de AI Engine (19 herramientas nativas)
- Repo público en GitHub — sin token necesario para actualizaciones automáticas

---

## [1.1.0] — 2026-06-17
- Formulario Club Zurca + shortcode [club_zurca_registro]
- Endpoint REST /zurca/v1/registro
- Tabla wp_zurca_club_members
- Plugin Update Checker integrado

---

## [1.0.0] — 2026-05-xx
- Versión inicial. Estructura base + cliente Glop API
