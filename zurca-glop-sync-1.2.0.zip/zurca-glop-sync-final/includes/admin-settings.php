<?php
/**
 * Ajustes WP Admin → Zurca
 *
 * @package ZurcaGlopSync
 * @since   1.0.0
 * @updated 1.2.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action('admin_menu', function() {
    add_menu_page('Zurca Glop Sync', 'Zurca', 'manage_options',
        'zurca-settings', 'zurca_settings_page', 'dashicons-store', 56);
});

add_action('admin_init', function() {
    register_setting('zurca_options', 'zurca_glop_api_key');
    register_setting('zurca_options', 'zurca_glop_api_url');
    register_setting('zurca_options', 'zurca_make_webhook_url');
    register_setting('zurca_options', 'zurca_brevo_api_key');
    register_setting('zurca_options', 'zurca_brevo_sms_sender');
});

function zurca_settings_page() { ?>
<div class="wrap">
  <h1>Zurca Glop Sync <span style="font-size:13px;color:#888;font-weight:400;">v<?php echo ZURCA_VERSION; ?></span></h1>

  <form method="post" action="options.php">
    <?php settings_fields('zurca_options'); ?>

    <h2>Glop API <span style="font-size:12px;color:#c00;">(pendiente — jueves)</span></h2>
    <table class="form-table">
      <tr>
        <th>URL API</th>
        <td><input type="text" name="zurca_glop_api_url"
             value="<?php echo esc_attr(get_option('zurca_glop_api_url')); ?>" class="regular-text"></td>
      </tr>
      <tr>
        <th>API Key</th>
        <td><input type="password" name="zurca_glop_api_key"
             value="<?php echo esc_attr(get_option('zurca_glop_api_key')); ?>" class="regular-text">
          <p class="description">Solicitar a soporte@glop.es</p></td>
      </tr>
    </table>

    <h2>Make (WhatsApp)</h2>
    <table class="form-table">
      <tr>
        <th>Webhook URL</th>
        <td><input type="text" name="zurca_make_webhook_url"
             value="<?php echo esc_attr(get_option('zurca_make_webhook_url')); ?>" class="regular-text">
          <p class="description">URL del escenario Make para notificaciones WhatsApp al registrarse</p></td>
      </tr>
    </table>

    <h2>Brevo SMS</h2>
    <table class="form-table">
      <tr>
        <th>API Key</th>
        <td><input type="password" name="zurca_brevo_api_key"
             value="<?php echo esc_attr(get_option('zurca_brevo_api_key')); ?>" class="regular-text"></td>
      </tr>
      <tr>
        <th>Remitente SMS</th>
        <td><input type="text" name="zurca_brevo_sms_sender"
             value="<?php echo esc_attr(get_option('zurca_brevo_sms_sender', 'Zurca')); ?>" maxlength="11">
          <p class="description">Máx. 11 caracteres · Debe estar aprobado en Brevo</p></td>
      </tr>
    </table>

    <?php submit_button('Guardar ajustes'); ?>
  </form>

  <hr>
  <h2>Shortcode formulario Club Zurca</h2>
  <p>La página ya está creada en <a href="<?php echo home_url('/club-zurca-herbolario-rincon-victoria'); ?>" target="_blank">
    <?php echo home_url('/club-zurca-herbolario-rincon-victoria'); ?></a></p>
  <p>Si necesitas añadir el formulario en otra página, usa el shortcode:</p>
  <code style="font-size:15px;padding:8px 14px;background:#f0f0f0;display:inline-block;border-radius:4px;">[club_zurca_registro]</code>

  <hr>
  <h2>Actualizaciones automáticas</h2>
  <p>Repositorio: <a href="https://github.com/salirenbuscadore/zurca-glop-sync" target="_blank">
    github.com/salirenbuscadore/zurca-glop-sync</a> (público — sin token necesario)</p>
  <p class="description">Para publicar una actualización: sube los archivos a GitHub y crea un nuevo Release con el tag de versión (ej: <code>v1.3.0</code>). WordPress detectará la actualización automáticamente.</p>
</div>
<?php }
