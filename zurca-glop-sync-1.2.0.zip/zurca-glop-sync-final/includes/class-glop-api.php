<?php
/**
 * Cliente Glop API
 *
 * @package ZurcaGlopSync
 * @since   1.0.0
 * @updated 1.2.0  Limpieza — eliminadas funciones duplicadas con MCP
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class Zurca_Glop_API {

    private string $base_url;
    private string $api_key;

    public function __construct() {
        $this->base_url = rtrim( get_option('zurca_glop_api_url', 'https://apidoc.glop.es'), '/' );
        $this->api_key  = get_option('zurca_glop_api_key', '');
    }

    private function headers(): array {
        return [
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/json',
        ];
    }

    /**
     * Crear cliente en Glop.
     * TODO v1.3.0 — ajustar campos al modelo real (confirmar jueves con soporte@glop.es)
     */
    public function crear_cliente( array $datos ) {
        $body = [
            'NOMBRE'   => $datos['nombre'] . ' ' . $datos['apellidos'],
            'TELEFONO' => $datos['telefono'],
            'CP'       => $datos['cp'],
            'EMAIL'    => $datos['email'] ?? '',
            'NOTAS'    => $datos['notas'] ?? '',
        ];

        $response = wp_remote_post( $this->base_url . '/clientes', [
            'headers' => $this->headers(),
            'body'    => wp_json_encode( $body ),
            'timeout' => 15,
        ]);

        if ( is_wp_error($response) ) return $response;

        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode( wp_remote_retrieve_body($response), true );

        if ( $code >= 400 ) {
            return new WP_Error( 'glop_error', $data['message'] ?? 'Error Glop API', ['status' => $code] );
        }

        return $data;
    }

    /**
     * Buscar cliente por teléfono.
     * TODO v1.3.0 — verificar endpoint real
     */
    public function buscar_cliente( string $telefono ) {
        $response = wp_remote_get( $this->base_url . '/clientes?telefono=' . urlencode($telefono), [
            'headers' => $this->headers(),
            'timeout' => 15,
        ]);
        if ( is_wp_error($response) ) return $response;
        return json_decode( wp_remote_retrieve_body($response), true );
    }
}

/**
 * Helper: crear cliente en Glop y guardar glop_cliente_id.
 * Activar en v1.3.0 desde zurca_handle_registro().
 */
function zurca_glop_crear_cliente( int $zurca_id ): void {
    global $wpdb;
    $tabla = $wpdb->prefix . 'zurca_club_members';
    $socio = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$tabla} WHERE id = %d", $zurca_id) );
    if ( ! $socio ) return;

    $api    = new Zurca_Glop_API();
    $result = $api->crear_cliente( (array) $socio );

    if ( ! is_wp_error($result) && ! empty($result['customer_id']) ) {
        $wpdb->update(
            $tabla,
            [ 'glop_cliente_id' => $result['customer_id'] ],
            [ 'id' => $zurca_id ],
            [ '%s' ], [ '%d' ]
        );
    }
}
