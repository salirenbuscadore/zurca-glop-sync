<?php
/**
 * Club Zurca — Formulario de registro + Endpoint REST
 * Shortcode: [club_zurca_registro]
 *
 * @package ZurcaGlopSync
 * @since   1.1.0
 * @updated 1.2.0
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// ── Shortcode ─────────────────────────────────────────────────
add_shortcode( 'club_zurca_registro', 'zurca_form_render' );

// ── Assets (solo en la página que usa el shortcode) ───────────
add_action( 'wp_enqueue_scripts', function() {
    global $post;
    if ( is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'club_zurca_registro') ) {
        wp_enqueue_style(  'zurca-club-form', ZURCA_PLUGIN_URL . 'assets/club-form.css', [], ZURCA_VERSION );
        wp_enqueue_script( 'zurca-club-form', ZURCA_PLUGIN_URL . 'assets/club-form.js',  [], ZURCA_VERSION, true );
        wp_localize_script( 'zurca-club-form', 'zurcaClub', [
            'endpoint' => rest_url('zurca/v1/registro'),
            'nonce'    => wp_create_nonce('wp_rest'),
        ]);
    }
});

// ── HTML del formulario ───────────────────────────────────────
function zurca_form_render() {
    ob_start(); ?>
    <div class="zurca-club-wrap">
      <div class="zurca-cabecera">
        <div class="zurca-logo-circle">&#127807;</div>
        <h2>Únete al Club Zurca</h2>
        <p>Tu herbolario de confianza en Rincón de la Victoria.<br>
           Regístrate y disfruta de ventajas exclusivas.</p>
      </div>
      <div class="zurca-beneficios">
        <span class="zurca-bene">&#127873; Descuentos exclusivos</span>
        <span class="zurca-bene">&#127807; Novedades primero</span>
        <span class="zurca-bene">&#128172; Consejos de salud</span>
      </div>
      <div class="zurca-form-box">
        <div class="zurca-form-inner" id="zurca-form-inner">

          <p class="zurca-seccion-label">Obligatorio</p>

          <div class="zurca-fila-dos">
            <div class="zurca-campo">
              <label for="zc-nombre">Nombre <span class="req">*</span></label>
              <input type="text" id="zc-nombre" placeholder="Tu nombre" autocomplete="given-name">
              <span class="zurca-error" id="zerr-nombre">Escribe tu nombre</span>
            </div>
            <div class="zurca-campo">
              <label for="zc-apellidos">Apellidos <span class="req">*</span></label>
              <input type="text" id="zc-apellidos" placeholder="Apellidos" autocomplete="family-name">
              <span class="zurca-error" id="zerr-apellidos">Escribe tus apellidos</span>
            </div>
          </div>

          <div class="zurca-campo">
            <label for="zc-telefono">Teléfono <span class="req">*</span></label>
            <input type="tel" id="zc-telefono" placeholder="612 345 678" autocomplete="tel" maxlength="15">
            <small>Tu número de socio en el Club Zurca</small>
            <span class="zurca-error" id="zerr-telefono">Introduce un teléfono español válido</span>
          </div>

          <div class="zurca-campo">
            <label for="zc-cp">Código postal <span class="req">*</span></label>
            <input type="text" id="zc-cp" placeholder="29730" maxlength="5" inputmode="numeric">
            <span class="zurca-error" id="zerr-cp">Introduce un código postal válido (5 dígitos)</span>
          </div>

          <hr class="zurca-divider">
          <p class="zurca-seccion-label">Opcional</p>

          <div class="zurca-fila-dos">
            <div class="zurca-campo">
              <label for="zc-email">Email <span class="opt">(opcional)</span></label>
              <input type="email" id="zc-email" placeholder="tucorreo@ejemplo.com" autocomplete="email">
              <small>Para pedidos en zurcanatural.com</small>
              <span class="zurca-error" id="zerr-email">Introduce un email válido</span>
            </div>
            <div class="zurca-campo">
              <label for="zc-cumple">Cumpleaños <span class="opt">(opcional)</span></label>
              <input type="date" id="zc-cumple" autocomplete="bday">
              <small>Para felicitarte &#127874;</small>
            </div>
          </div>

          <div class="zurca-consentimiento">
            <input type="checkbox" id="zc-gdpr">
            <label for="zc-gdpr">
              Acepto recibir comunicaciones de Zurca Mercado Natural.
              Puedes darte de baja en cualquier momento.
              <a href="mailto:tiendaonline@zurcanatural.com">Política de privacidad</a>.
            </label>
          </div>
          <span class="zurca-error" id="zerr-gdpr">Necesitamos tu consentimiento para registrarte</span>

          <button type="button" id="zurca-btn-registro" class="zurca-btn">
            <span id="zurca-btn-texto">Registrarme en el Club</span>
          </button>
          <div class="zurca-error-global" id="zurca-error-global"></div>
        </div>

        <div class="zurca-exito" id="zurca-exito" style="display:none;">
          <div class="zurca-exito-icon">&#127807;</div>
          <h3>&#161;Ya eres del Club!</h3>
          <p>Bienvenida, <strong id="zurca-exito-nombre"></strong>.<br>
             Nos vemos pronto en la tienda &#128154;</p>
        </div>
      </div>
    </div>
    <?php
    return ob_get_clean();
}

// ── Endpoint REST POST /wp-json/zurca/v1/registro ─────────────
add_action( 'rest_api_init', function() {
    register_rest_route('zurca/v1', '/registro', [
        'methods'             => 'POST',
        'callback'            => 'zurca_handle_registro',
        'permission_callback' => '__return_true',
    ]);
});

function zurca_handle_registro( WP_REST_Request $request ) {
    if ( ! wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest') ) {
        return new WP_Error('forbidden', 'Petición no autorizada', ['status' => 403]);
    }

    $nombre    = sanitize_text_field( $request->get_param('nombre') );
    $apellidos = sanitize_text_field( $request->get_param('apellidos') );
    $telefono  = preg_replace('/[\s\-\.]/', '', sanitize_text_field($request->get_param('telefono')));
    $cp        = sanitize_text_field( $request->get_param('cp') );
    $email     = sanitize_email( $request->get_param('email') );
    $cumple    = sanitize_text_field( $request->get_param('cumpleanos') );
    $gdpr      = (bool) $request->get_param('gdpr');

    if ( empty($nombre) )                                      return new WP_Error('val', 'Nombre obligatorio',       ['status'=>400]);
    if ( empty($apellidos) )                                   return new WP_Error('val', 'Apellidos obligatorios',   ['status'=>400]);
    if ( !preg_match('/^(\+?34)?[6789]\d{8}$/', $telefono) )  return new WP_Error('val', 'Teléfono inválido',        ['status'=>400]);
    if ( !preg_match('/^\d{5}$/', $cp) )                       return new WP_Error('val', 'Código postal inválido',   ['status'=>400]);
    if ( !empty($email) && !is_email($email) )                 return new WP_Error('val', 'Email inválido',           ['status'=>400]);
    if ( !$gdpr )                                              return new WP_Error('val', 'Consentimiento requerido', ['status'=>400]);

    global $wpdb;
    $tabla = $wpdb->prefix . 'zurca_club_members';
    if ( $wpdb->get_var($wpdb->prepare("SELECT id FROM {$tabla} WHERE telefono = %s", $telefono)) ) {
        return new WP_Error('duplicate', 'Ya existe un socio con ese teléfono', ['status'=>409]);
    }

    // Crear cuenta WooCommerce si hay email
    $wc_id = null;
    if ( !empty($email) && class_exists('WooCommerce') ) {
        $existing = email_exists($email);
        $wc_id = $existing ?: wc_create_new_customer($email, '', wp_generate_password(12, false), [
            'first_name' => $nombre, 'last_name' => $apellidos,
        ]);
        if ( is_wp_error($wc_id) ) $wc_id = null;
        if ( $wc_id ) {
            update_user_meta($wc_id, 'billing_first_name', $nombre);
            update_user_meta($wc_id, 'billing_last_name',  $apellidos);
            update_user_meta($wc_id, 'billing_phone',      $telefono);
            update_user_meta($wc_id, 'billing_postcode',   $cp);
            update_user_meta($wc_id, 'zurca_club_member',  '1');
            if ($cumple) update_user_meta($wc_id, 'zurca_cumpleanos', $cumple);
        }
    }

    $wpdb->insert($tabla, [
        'nombre'          => $nombre,
        'apellidos'       => $apellidos,
        'telefono'        => $telefono,
        'cp'              => $cp,
        'email'           => $email ?: null,
        'cumpleanos'      => $cumple  ?: null,
        'gdpr_aceptado'   => 1,
        'gdpr_fecha'      => current_time('mysql'),
        'wc_customer_id'  => $wc_id,
        'glop_cliente_id' => null, // TODO v1.3.0
        'fecha_registro'  => current_time('mysql'),
    ], ['%s','%s','%s','%s','%s','%s','%d','%s','%d','%d','%s']);

    $nuevo_id = $wpdb->insert_id;

    // TODO v1.3.0: zurca_glop_crear_cliente( $nuevo_id );
    // TODO v1.3.0: notificación WhatsApp vía Make

    return rest_ensure_response([
        'success' => true,
        'mensaje' => 'Bienvenida al Club Zurca, ' . esc_html($nombre) . '!',
        'id'      => $nuevo_id,
    ]);
}

// ── Crear tabla BD ────────────────────────────────────────────
function zurca_club_crear_tabla() {
    global $wpdb;
    $tabla   = $wpdb->prefix . 'zurca_club_members';
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS {$tabla} (
        id              INT UNSIGNED NOT NULL AUTO_INCREMENT,
        nombre          VARCHAR(100) NOT NULL,
        apellidos       VARCHAR(150) NOT NULL,
        telefono        VARCHAR(20)  NOT NULL UNIQUE COMMENT 'ID principal del socio',
        cp              VARCHAR(10)  NOT NULL,
        email           VARCHAR(200) DEFAULT NULL,
        cumpleanos      DATE         DEFAULT NULL,
        gdpr_aceptado   TINYINT(1)   NOT NULL DEFAULT 1,
        gdpr_fecha      DATETIME     NOT NULL,
        wc_customer_id  BIGINT       DEFAULT NULL,
        glop_cliente_id VARCHAR(50)  DEFAULT NULL COMMENT 'Rellenar en v1.3.0',
        fecha_registro  DATETIME     NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY uk_telefono (telefono),
        KEY idx_cp   (cp),
        KEY idx_glop (glop_cliente_id)
    ) {$charset};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
